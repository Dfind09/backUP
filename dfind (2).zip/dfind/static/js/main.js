// --- 전역 상태 변수 ---
let allPosts = [];
let allGalleries = [];
let selectedGallery = null;
let searchTerm = "";
let selectedPost = null;
let currentUser = null;
let likedPostIds = new Set();

// 채팅 관련 상태
let allChatrooms = [];
let selectedChatroom = null;
let chatRefreshInterval = null;
let chatListRefreshInterval = null; 

// 게시글 상세 갱신
let postDetailRefreshInterval = null;

// [추가] 게시글 목록 갱신
let postListRefreshInterval = null;
let isFirstPostLoad = true; // [추가] 첫 로드인지 확인


// --- DOM 요소 ---
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

const $logo = $("#logo");
const $searchInput = $("#search-input");
const $openNewPostModalBtn = $("#open-new-post-modal-btn");

const $galleryNav = $("#gallery-nav");
const $mainContentTitle = $("#main-content-title");
const $postListContainer = $("#post-list-container");
const $loadingPlaceholder = $("#loading-placeholder");

const $authButtonsContainer = $("#auth-buttons-container");

// 게시글 상세 모달
const $postDetailModal = $("#post-detail-modal");
const $closeDetailModalBtn = $("#close-detail-modal-btn");
const $postDetailHeader = $("#post-detail-header");
const $postDetailContent = $("#post-detail-content");
const $postDetailMeta = $("#post-detail-meta");
const $postDetailActions = $("#post-detail-actions");

// 새 글 모달
const $newPostModal = $("#new-post-modal");
const $newPostForm = $("#new-post-form");
const $closeNewPostModalBtn = $("#close-new-post-modal-btn");
const $newPostGallerySelect = $("#new-post-gallery");

// 로그인 모달
const $loginModal = $("#login-modal");
const $loginForm = $("#login-form");
const $closeLoginModalBtn = $("#close-login-modal-btn");
const $toggleToRegister = $("#toggle-to-register");

// 회원가입 모달
const $registerModal = $("#register-modal");
const $registerForm = $("#register-form");
const $closeRegisterModalBtn = $("#close-register-modal-btn");
const $toggleToLogin = $("#toggle-to-login");

// 채팅 관련 DOM
const $openChatListBtn = $("#open-chat-list-btn");
const $chatBadge = $("#chat-badge");
const $chatListModal = $("#chat-list-modal");
const $closeChatListModalBtn = $("#close-chat-list-modal-btn");
const $chatListContainer = $("#chat-list-container");

const $chatDetailModal = $("#chat-detail-modal");
const $closeChatDetailModalBtn = $("#close-chat-detail-modal-btn");
const $chatOtherUserName = $("#chat-other-user-name");
const $chatPostTitle = $("#chat-post-title");
const $chatMessagesContainer = $("#chat-messages-container");
const $chatMessageForm = $("#chat-message-form");
const $chatMessageInput = $("#chat-message-input");

// 커스텀 알림
const $customAlertModal = $("#custom-alert-modal");
const $customAlertMessage = $("#custom-alert-message");
const $customAlertCloseBtn = $("#custom-alert-close-btn");

// --- 유틸리티 함수 ---

function createIconsSafe() {
    if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
        try {
            lucide.createIcons();
        } catch (error) {
            console.error('Error creating lucide icons:', error);
        }
    }
}

function customAlert(message) {
    $customAlertMessage.textContent = message;
    $customAlertModal.classList.remove("hidden");
}

function closeCustomAlert() {
    $customAlertModal.classList.add("hidden");
}

function customConfirm(message) {
    // app.py에 custom confirm 로직이 없으므로, 기본 confirm 사용
    return confirm(message);
}

function formatTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return '방금 전';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}분 전`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}시간 전`;
    return `${Math.floor(seconds / 86400)}일 전`;
}

function formatChatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();

    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const msgDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

    const diffTime = today.getTime() - msgDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
        return date.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', hour12: true });
    } else if (diffDays === 1) {
        return '어제';
    } else if (diffDays < 7) {
        return `${diffDays}일 전`;
    } else {
        return date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' });
    }
}

function getGalleryById(galleryId) {
    return allGalleries.find(g => g.id === galleryId) || { name: '알 수 없음', icon: 'HelpCircle' };
}

// --- 모달 제어 함수 ---
function openLoginModal() {
    closeRegisterModal();
    $loginModal.classList.remove('hidden');
}
function closeLoginModal() {
    $loginModal.classList.add('hidden');
    $loginForm.reset();
}

function openRegisterModal() {
    closeLoginModal();
    $registerModal.classList.remove('hidden');
}
function closeRegisterModal() {
    $registerModal.classList.add('hidden');
    $registerForm.reset();
}

function openNewPostModal() {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }
    $newPostModal.classList.remove('hidden');
}
function closeNewPostModal() {
    $newPostModal.classList.add('hidden');
    $newPostForm.reset();
}

function closeDetailModal() {
    $postDetailModal.classList.add('hidden');
    selectedPost = null;
    
    if (postDetailRefreshInterval) {
        clearInterval(postDetailRefreshInterval);
        postDetailRefreshInterval = null;
    }
    
    // [수정] 5초로 유지 (1초는 너무 과부하)
    if (!postListRefreshInterval) {
         postListRefreshInterval = setInterval(fetchPosts, 5000); // 5초
    }
}

function openChatListModal() {
    renderChatList(); 
    $chatListModal.classList.remove('hidden');
}
function closeChatListModal() {
    $chatListModal.classList.add('hidden');
}

function openChatDetailModal() {
    $chatDetailModal.classList.remove('hidden');
}
function closeChatDetailModal() {
    $chatDetailModal.classList.add('hidden');
    selectedChatroom = null;
    $chatMessagesContainer.innerHTML = '';
    $chatMessageForm.reset();
    
    if (chatRefreshInterval) {
        clearInterval(chatRefreshInterval);
        chatRefreshInterval = null;
    }
    
    // [추가] 폼 상태 리셋
    $chatMessageInput.disabled = false;
    $chatMessageInput.placeholder = "메시지를 입력하세요...";
    $chatMessageForm.querySelector('button[type="submit"]').disabled = false;
}

// --- 렌더링 함수 ---

function renderAuthButtons() {
    let html = '';
    if (currentUser) {
        html = `
            <span class="text-sm text-gray-400 hidden md:block"><strong>${currentUser.username}</strong>님</span>
            <button id="logout-btn" class="text-gray-400 hover:text-pink-400 font-bold px-3 py-2 rounded-lg hover:bg-gray-800 transition">로그아웃</button>
        `;
        $openChatListBtn.classList.remove('hidden');
    } else {
        html = `
            <button id="open-login-modal-btn" class="text-white hover:text-pink-400 font-bold px-4 py-2 rounded-lg hover:bg-gray-800 transition">
                로그인 / 회원가입
            </button>
        `;
        $openChatListBtn.classList.add('hidden');
    }
    $authButtonsContainer.innerHTML = html;
    
    if (currentUser) {
        $('#logout-btn').addEventListener('click', handleLogout);
    } else {
        $('#open-login-modal-btn').addEventListener('click', openLoginModal);
    }
    
    createIconsSafe();
}

function renderSidebar() {
    let html = `
        <button
            data-gallery-id="null"
            class="w-full text-left px-4 py-3 rounded-lg transition flex items-center gap-3 font-bold ${
                selectedGallery === null 
                    ? 'bg-gradient-to-r from-pink-600 to-pink-500 text-white shadow-lg shadow-pink-600/30' 
                    : 'text-gray-300 hover:bg-gray-800/50 hover:text-pink-400'
            }"
        >
            <i data-lucide="layout-grid" class="w-5 h-5"></i>
            전체 보기
        </button>
    `;

    allGalleries.forEach(gallery => {
        html += `
            <button
                data-gallery-id="${gallery.id}"
                class="w-full text-left px-4 py-3 rounded-lg transition flex items-center gap-3 font-bold ${
                    selectedGallery === gallery.id 
                        ? 'bg-gradient-to-r from-pink-600 to-pink-500 text-white shadow-lg shadow-pink-600/30' 
                        : 'text-gray-300 hover:bg-gray-800/50 hover:text-pink-400'
                }"
            >
                <i data-lucide="${gallery.icon || 'HelpCircle'}" class="w-5 h-5"></i>
                ${gallery.name}
            </button>
        `;
    });

    $galleryNav.innerHTML = html;
    createIconsSafe();
}

function populateNewPostGalleryOptions() {
     let optionsHtml = '<option value="">카테고리를 선택하세요</option>';
     allGalleries.forEach(gallery => {
        optionsHtml += `<option value="${gallery.id}">${gallery.name}</option>`;
     });
     $newPostGallerySelect.innerHTML = optionsHtml;
}

function renderPostList() {
    const filteredPosts = allPosts.filter(post => {
        const matchesGallery = !selectedGallery || post.gallery === selectedGallery;
        const matchesSearch = !searchTerm || 
            post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
            post.author_username.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesGallery && matchesSearch;
    });

    $mainContentTitle.textContent = selectedGallery 
        ? getGalleryById(selectedGallery).name 
        : '전체 팟 모집';

    $postListContainer.innerHTML = '';
    
    $loadingPlaceholder.classList.add('hidden');
    
    if (filteredPosts.length === 0) {
        $postListContainer.innerHTML = `
            <div class="p-12 text-center text-gray-500">
                게시글이 없습니다.
            </div>
        `;
        return;
    }

    filteredPosts.forEach(post => {
        const gallery = getGalleryById(post.gallery);
        const isLiked = likedPostIds.has(post.id);
        
        const postElement = document.createElement('div');
        postElement.className = "p-5 hover:bg-gray-800/50 transition cursor-pointer";
        postElement.dataset.postId = post.id;
        
        postElement.innerHTML = `
            <div class="flex items-start gap-4">
                <div class="flex-1">
                    <div class="flex items-center gap-2 mb-2 flex-wrap">
                        <span class="text-xs px-3 py-1 bg-gradient-to-r from-pink-600 to-pink-500 text-white rounded-full font-bold shadow-md">
                            ${gallery.name}
                        </span>
                        ${post.isCompleted ? `
                            <span class="text-xs px-3 py-1 bg-gray-700 text-gray-300 rounded-full font-bold flex items-center gap-1">
                                <i data-lucide="check-circle" class="w-3 h-3"></i>
                                모집완료
                            </span>
                        ` : `
                            <span class="text-xs px-3 py-1 bg-pink-900/50 text-pink-400 rounded-full font-bold border border-pink-600/30">
                                모집중 (${post.currentMembers}/${post.totalMembers})
                            </span>
                        `}
                        <span class="text-xs text-gray-500">${post.author_username}</span>
                    </div>
                    <h3 class="font-bold text-lg mb-2 text-white hover:text-pink-400 transition">${post.title}</h3>
                    <p class="text-sm text-gray-400 mb-3 line-clamp-2">${post.content}</p>
                    <div class="flex items-center gap-5 text-xs text-gray-500">
                        <span class="flex items-center gap-1">
                            <i data-lucide="clock" class="w-4 h-4"></i>
                            ${formatTimeAgo(post.timestamp)}
                        </span>
                        <span class="flex items-center gap-1">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                            ${post.views}
                        </span>
                        <span class="flex items-center gap-1 ${isLiked ? 'text-pink-500 font-bold' : 'text-pink-400'}">
                            <i data-lucide="thumbs-up" class="w-4 h-4 ${isLiked ? 'fill-current' : ''}"></i>
                            ${post.likes}
                        </span>
                    </div>
                </div>
            </div>
        `;
        
        postElement.addEventListener('click', () => handleOpenPost(post.id));
        $postListContainer.appendChild(postElement);
    });

    createIconsSafe();
}

function renderPostDetailModal() {
    if (!selectedPost) return;

    const post = selectedPost;
    const gallery = getGalleryById(post.gallery);
    const isLiked = selectedPost.liked_by_user;
    const hasJoined = selectedPost.has_joined; 

    $postDetailHeader.innerHTML = `
        <div class="flex items-center gap-3 mb-3 flex-wrap">
            <span class="text-sm px-4 py-1.5 bg-gradient-to-r from-pink-600 to-pink-500 text-white rounded-full font-bold shadow-lg">
                ${gallery.name}
            </span>
            ${post.isCompleted ? `
                <span class="text-sm px-4 py-1.5 bg-gray-700 text-gray-300 rounded-full font-bold flex items-center gap-2">
                    <i data-lucide="check-circle" class="w-4 h-4"></i>
                    모집완료
                </span>
            ` : `
                <span class="text-sm px-4 py-1.5 bg-pink-900/50 text-pink-400 rounded-full font-bold border-2 border-pink-600/50">
                    모집중 (${post.currentMembers}/${post.totalMembers})
                </span>
            `}
        </div>
        <h2 class="text-3xl font-black mb-3 text-white">${post.title}</h2>
        <div class="flex items-center gap-4 text-sm text-gray-400">
            <span>${post.author_username}</span>
            <span>•</span>
            <span>${formatTimeAgo(post.timestamp)}</span>
        </div>
    `;

    $postDetailContent.textContent = post.content;

    $postDetailMeta.innerHTML = `
        <span class="flex items-center gap-2">
            <i data-lucide="eye" class="w-5 h-5"></i>
            조회 ${post.views}
        </span>
        <button id="detail-like-btn" data-post-id="${post.id}" 
            class="flex items-center gap-2 ${isLiked ? 'text-pink-500 font-bold' : 'text-gray-400 hover:text-pink-400'} transition">
            <i data-lucide="thumbs-up" class="w-5 h-5 ${isLiked ? 'fill-current' : ''}"></i>
            좋아요 ${post.likes}
        </button>
    `;
    
    let actionButtonsHTML = '';
    
    if (currentUser && currentUser.user_id !== post.user_id) {
        actionButtonsHTML = `
            <div class="grid grid-cols-2 gap-4">
                <button
                    id="detail-join-btn"
                    data-post-id="${post.id}"
                    ${post.isCompleted && !hasJoined ? 'disabled' : ''}
                    class="py-4 rounded-xl font-black text-lg flex items-center justify-center gap-3 transition shadow-lg ${
                        hasJoined
                            ? 'bg-red-800 text-white hover:bg-red-700 border-2 border-red-700'
                            : (post.isCompleted
                                ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                                : 'bg-gradient-to-r from-pink-600 to-pink-500 text-white hover:from-pink-500 hover:to-pink-600 shadow-pink-600/30')
                    }"
                >
                    ${hasJoined 
                        ? '<i data-lucide="user-minus" class="w-6 h-6"></i> 참가 취소하기'
                        : (post.isCompleted 
                            ? '<i data-lucide="check-circle" class="w-6 h-6"></i> 모집 완료됨'
                            : '<i data-lucide="user-plus" class="w-6 h-6"></i> 참가하기')
                    }
                </button>
                <button
                    id="detail-inquiry-btn"
                    data-post-id="${post.id}"
                    class="bg-gray-800 text-white py-4 rounded-xl hover:bg-gray-700 transition font-black text-lg flex items-center justify-center gap-3 border-2 border-gray-700"
                >
                    <i data-lucide="message-circle" class="w-6 h-6"></i>
                    문의하기
                </button>
            </div>
        `;
    }
    
    if (currentUser && currentUser.user_id === post.user_id) {
        
        if (post.participants && post.participants.length > 0) {
            actionButtonsHTML += `<div class="mt-0">
                <h4 class="font-bold text-lg text-white mb-3">참가자 목록 (${post.participants.length}명)</h4>
                <ul class="space-y-2 max-h-40 overflow-y-auto bg-gray-800/50 p-3 rounded-lg border border-gray-700">`;
            
            post.participants.forEach(p => {
                actionButtonsHTML += `
                    <li class="flex items-center justify-between p-2 rounded bg-gray-800">
                        <span class="text-white font-medium">${p.username}</span>
                        <div class="flex gap-2">
                            <button class="author-msg-btn text-pink-400 hover:text-pink-300 p-1" data-user-id="${p.user_id}" data-post-id="${post.id}" title="메시지 보내기">
                                <i data-lucide="message-circle" class="w-4 h-4"></i>
                            </button>
                            <button class="author-reject-btn text-red-500 hover:text-red-400 p-1" data-user-id="${p.user_id}" data-post-id="${post.id}" title="참가 거부">
                                <i data-lucide="x-circle" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </li>
                `;
            });
            
            actionButtonsHTML += `</ul></div>`;
        } else {
             actionButtonsHTML += `<p class="text-sm text-gray-500 text-center mt-0 mb-4">아직 참가자가 없습니다.</p>`;
        }
        
        actionButtonsHTML += `
            <button
                id="detail-delete-btn"
                data-post-id="${post.id}"
                class="mt-4 bg-red-800 text-white py-4 rounded-xl hover:bg-red-700 transition font-black text-lg flex items-center justify-center gap-3 border-2 border-red-700 w-full"
            >
                <i data-lucide="trash-2" class="w-6 h-6"></i>
                이 팟 삭제하기
            </button>
        `;
    }

    $postDetailActions.innerHTML = actionButtonsHTML;

    createIconsSafe();
    
    const likeBtn = $("#detail-like-btn");
    if (likeBtn) likeBtn.addEventListener('click', (e) => handleLike(e.currentTarget.dataset.postId));
    
    const joinBtn = $("#detail-join-btn");
    if (joinBtn) joinBtn.addEventListener('click', (e) => {
        const postId = e.currentTarget.dataset.postId;
        if (selectedPost.has_joined) {
            handleCancelJoin(postId);
        } else {
            handleJoin(postId);
        }
    });

    const inquiryBtn = $("#detail-inquiry-btn");
    if (inquiryBtn) inquiryBtn.addEventListener('click', (e) => handleInquiry(e.currentTarget.dataset.postId));
    
    const deleteBtn = $("#detail-delete-btn");
    if (deleteBtn) deleteBtn.addEventListener('click', (e) => handleDeletePost(e.currentTarget.dataset.postId));

    $$('.author-msg-btn').forEach(btn => btn.addEventListener('click', (e) => {
        const userId = e.currentTarget.closest('button').dataset.userId;
        const postId = e.currentTarget.closest('button').dataset.postId;
        handleInquiryByAuthor(postId, userId);
    }));
    
    $$('.author-reject-btn').forEach(btn => btn.addEventListener('click', (e) => {
        const userId = e.currentTarget.closest('button').dataset.userId;
        const postId = e.currentTarget.closest('button').dataset.postId;
        handleRejectParticipant(postId, userId);
    }));
}

function updateChatBadge(unreadCount) {
    if (unreadCount > 0) {
        $chatBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
        $chatBadge.classList.remove('hidden');
    } else {
        $chatBadge.classList.add('hidden');
    }
}

function renderChatList() {
    if (allChatrooms.length === 0) {
        $chatListContainer.innerHTML = `
            <div class="p-12 text-center text-gray-500">
                채팅방이 없습니다.
            </div>
        `;
        return;
    }

    $chatListContainer.innerHTML = '';
    allChatrooms.forEach(chatroom => {
        const chatroomElement = document.createElement('div');
        chatroomElement.className = "p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800 transition cursor-pointer border border-gray-700";
        chatroomElement.dataset.chatroomId = chatroom.id;
        
        chatroomElement.innerHTML = `
            <div class="flex items-start justify-between gap-3">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-1">
                        <h3 class="font-bold text-white truncate">${chatroom.other_user_name}</h3>
                        ${chatroom.unread_count > 0 ? `
                            <span class="bg-pink-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                                ${chatroom.unread_count}
                            </span>
                        ` : ''}
                    </div>
                    <p class="text-xs text-gray-400 mb-2 truncate">${chatroom.post_title}</p>
                    <p class="text-sm text-gray-300 truncate">${chatroom.last_message}</p>
                </div>
                <div class="flex flex-col items-end gap-2">
                    <span class="text-xs text-gray-500">${formatChatTime(chatroom.last_message_at)}</span>
                    <button class="delete-chat-btn text-gray-500 hover:text-red-500 transition p-1" data-chatroom-id="${chatroom.id}">
                        <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        `;
        
        chatroomElement.addEventListener('click', (e) => {
            if (e.target.closest('.delete-chat-btn')) {
                e.stopPropagation();
                handleDeleteChatroom(chatroom.id);
                return;
            }
            handleOpenChatDetail(chatroom.id);
        });
        
        $chatListContainer.appendChild(chatroomElement);
    });

    createIconsSafe();
}

// [수정] 시스템 메시지 렌더링
function renderChatMessages(messages) {
    if (!selectedChatroom) return;

    if (messages.length === 0) {
        $chatMessagesContainer.innerHTML = `
            <div class="text-center text-gray-500 py-8">
                <i data-lucide="message-circle" class="w-12 h-12 mx-auto mb-3 text-gray-600"></i>
                <p>메시지를 시작해보세요!</p>
            </div>
        `;
        createIconsSafe();
        return;
    }

    $chatMessagesContainer.innerHTML = '';
    messages.forEach(message => {
        const messageElement = document.createElement('div');

        // [추가] 시스템 메시지 (나감/들어옴)
        if (message.is_system_message) {
            messageElement.className = 'flex justify-center';
            messageElement.innerHTML = `
                <div class="text-center text-xs text-gray-500 bg-gray-800 px-3 py-1 rounded-full my-2">
                    ${message.content}
                </div>
            `;
        } 
        // 기존 사용자 메시지
        else {
            const isMine = message.sender_id === currentUser.user_id;
            messageElement.className = `flex ${isMine ? 'justify-end' : 'justify-start'}`;
            messageElement.innerHTML = `
                <div class="max-w-[70%]">
                    ${!isMine ? `<p class="text-xs text-gray-400 mb-1">${message.sender_name}</p>` : ''}
                    <div class="rounded-lg p-3 ${
                        isMine 
                            ? 'bg-gradient-to-r from-pink-600 to-pink-500 text-white' 
                            : 'bg-gray-800 text-gray-300'
                    }">
                        <p class="text-base whitespace-pre-wrap break-words">${message.content}</p>
                    </div>
                    <p class="text-xs text-gray-500 mt-1 ${isMine ? 'text-right' : 'text-left'}">
                        ${formatChatTime(message.timestamp)}
                    </p>
                </div>
            `;
        }
        
        $chatMessagesContainer.appendChild(messageElement);
    });

    $chatMessagesContainer.scrollTop = $chatMessagesContainer.scrollHeight;
}

// [추가] 상대방이 나갔는지 확인하고 입력창 상태 변경
function updateChatInputState() {
    if (!selectedChatroom || !currentUser) return;
    
    const amIUser1 = currentUser.user_id === selectedChatroom.user1_id;
    const otherUserHasLeft = amIUser1 ? selectedChatroom.user2_left : selectedChatroom.user1_left;
    
    if (otherUserHasLeft) {
        $chatMessageInput.disabled = true;
        $chatMessageInput.placeholder = "상대방이 채팅방을 나갔습니다.";
        $chatMessageForm.querySelector('button[type="submit"]').disabled = true;
    } else {
        $chatMessageInput.disabled = false;
        $chatMessageInput.placeholder = "메시지를 입력하세요...";
        $chatMessageForm.querySelector('button[type="submit"]').disabled = false;
    }
}


// --- API 호출 함수 ---

async function fetchStatus() {
    try {
        const response = await fetch('/api/status');
        if (!response.ok) throw new Error('Status check failed');
        const data = await response.json();
        currentUser = data.logged_in ? data : null;
    } catch (error) {
        console.error(error);
        currentUser = null;
    }
    renderAuthButtons();
}

async function fetchGalleries() {
    try {
        const response = await fetch('/api/galleries');
        if (!response.ok) throw new Error('카테고리 로딩 실패');
        allGalleries = await response.json();
        renderSidebar();
        populateNewPostGalleryOptions();
    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function fetchPosts() {
    try {
        if (isFirstPostLoad) {
            $loadingPlaceholder.classList.remove('hidden');
            $postListContainer.innerHTML = '';
        }
        
        const response = await fetch('/api/posts');
        if (!response.ok) throw new Error('게시글 로딩 실패');
        
        const data = await response.json();
        
        const newPostsJson = JSON.stringify(data.posts);
        const oldPostsJson = JSON.stringify(allPosts);
        const newLikedJson = JSON.stringify(data.liked_by_user);
        const oldLikedJson = JSON.stringify(Array.from(likedPostIds));

        if (newPostsJson !== oldPostsJson || newLikedJson !== oldLikedJson) {
            allPosts = data.posts;
            likedPostIds = new Set(data.liked_by_user);
            renderPostList(); 
        }
        
        if (isFirstPostLoad) {
            $loadingPlaceholder.classList.add('hidden');
            isFirstPostLoad = false;
        }

    } catch (error) { 
        console.error(error);
        if (isFirstPostLoad) {
            $loadingPlaceholder.classList.add('hidden');
            $postListContainer.innerHTML = `<div class="p-12 text-center text-red-500">게시글을 불러오는 데 실패했습니다.</div>`;
            isFirstPostLoad = false;
        }
    } 
}


async function fetchChatrooms() {
    if (!currentUser) return;
    
    try {
        const response = await fetch('/api/chatrooms');
        if (!response.ok) throw new Error('채팅방 로딩 실패');
        
        const data = await response.json();
        allChatrooms = data.chatrooms;
        updateChatBadge(data.total_unread);
        
        if (!$chatListModal.classList.contains('hidden')) {
            renderChatList();
        }
    } catch (error) {
        console.error(error);
    }
}

// --- 데이터 로드 ---
async function fetchAllData() {
    await fetchStatus();
    await fetchGalleries();
    await fetchPosts(); 
    
    if (postListRefreshInterval) clearInterval(postListRefreshInterval);
    
    // 5초 간격 (1초는 서버 부담)
    const POST_REFRESH_INTERVAL = 5000; 
    postListRefreshInterval = setInterval(fetchPosts, POST_REFRESH_INTERVAL);
    
    
    if (currentUser) {
        await fetchChatrooms(); 
        
        if (chatListRefreshInterval) clearInterval(chatListRefreshInterval);
        chatListRefreshInterval = setInterval(fetchChatrooms, 5000); 
    }
}

// --- 이벤트 핸들러 ---

async function handleOpenPost(postId) {
    try {
        if (postListRefreshInterval) {
            clearInterval(postListRefreshInterval);
            postListRefreshInterval = null;
        }

        const response = await fetch(`/api/posts/${postId}/view`, { method: 'POST' });
        if (!response.ok) throw new Error('게시글을 불러올 수 없습니다.');
        
        selectedPost = await response.json();
        
        const index = allPosts.findIndex(p => p.id == selectedPost.id);
        if (index !== -1) {
            allPosts[index].views = selectedPost.views;
            renderPostList();
        }
        
        renderPostDetailModal();
        $postDetailModal.classList.remove('hidden');

        if (postDetailRefreshInterval) clearInterval(postDetailRefreshInterval);
        postDetailRefreshInterval = setInterval(() => {
            refreshPostDetail(postId);
        }, 1000); // 상세 모달은 1초 갱신

    } catch (error) {
        console.error(error);
        customAlert(error.message);
        if (!postListRefreshInterval) {
             postListRefreshInterval = setInterval(fetchPosts, 5000); 
        }
    }
}

async function refreshPostDetail(postId) {
    if (!selectedPost || selectedPost.id != postId || $postDetailModal.classList.contains('hidden')) {
        if (postDetailRefreshInterval) clearInterval(postDetailRefreshInterval);
        postDetailRefreshInterval = null;
        return;
    }
    
    try {
        const response = await fetch(`/api/posts/${postId}`); 
        if (!response.ok) {
            throw new Error('Post refresh failed');
        }
        
        const refreshedPost = await response.json();
        
        selectedPost = refreshedPost;
        
        const index = allPosts.findIndex(p => p.id == postId);
        if (index !== -1) {
            allPosts[index].currentMembers = refreshedPost.currentMembers;
            allPosts[index].isCompleted = refreshedPost.isCompleted;
        }
        
        renderPostDetailModal();

    } catch (error) {
        console.error('Error refreshing post detail:', error);
        if (postDetailRefreshInterval) clearInterval(postDetailRefreshInterval);
        postDetailRefreshInterval = null;
    }
}


async function handleLike(postId) {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}/like`, { method: 'POST' });
        
        if (response.status === 401) {
            customAlert("로그인이 필요합니다.");
            openLoginModal();
            return;
        }
        if (!response.ok) throw new Error('좋아요 처리에 실패했습니다.');
        
        const updatedPost = await response.json();

        if (selectedPost && selectedPost.id == postId) {
            selectedPost = updatedPost;
            renderPostDetailModal();
        }
        
        const index = allPosts.findIndex(p => p.id == postId);
        if (index !== -1) {
            allPosts[index].likes = updatedPost.likes;
            allPosts[index].liked_by_user = updatedPost.liked_by_user;
        }
        
        if (updatedPost.liked_by_user) {
            likedPostIds.add(updatedPost.id);
        } else {
            likedPostIds.delete(updatedPost.id);
        }
        
        renderPostList(); 
    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleJoin(postId) {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}/join`, { method: 'POST' });
        const data = await response.json();

        if (response.status === 401) {
            customAlert("로그인이 필요합니다.");
            openLoginModal();
            return;
        }
        if (!response.ok) {
            throw new Error(data.error || '참가 처리에 실패했습니다.');
        }

        const updatedPost = data;
        
        if (selectedPost && selectedPost.id == postId) {
            selectedPost = updatedPost;
            renderPostDetailModal();
        }

        const index = allPosts.findIndex(p => p.id == postId);
        if (index !== -1) {
            allPosts[index].currentMembers = updatedPost.currentMembers;
            allPosts[index].isCompleted = updatedPost.isCompleted;
        }
        
        renderPostList();
        customAlert('참가 신청이 완료되었습니다!');

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleCancelJoin(postId) {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}/cancel_join`, { method: 'POST' });
        const data = await response.json();

        if (response.status === 401) {
            customAlert("로그인이 필요합니다.");
            openLoginModal();
            return;
        }
        if (!response.ok) {
            throw new Error(data.error || '참가 취소에 실패했습니다.');
        }

        const updatedPost = data;
        
        if (selectedPost && selectedPost.id == postId) {
            selectedPost = updatedPost;
            renderPostDetailModal();
        }

        const index = allPosts.findIndex(p => p.id == postId);
        if (index !== -1) {
            allPosts[index].currentMembers = updatedPost.currentMembers;
            allPosts[index].isCompleted = updatedPost.isCompleted;
        }
        
        renderPostList();
        customAlert('참가를 취소했습니다.');

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleRejectParticipant(postId, userId) {
    if (!currentUser || currentUser.user_id !== selectedPost.user_id) {
        customAlert("권한이 없습니다.");
        return;
    }
    
    if (!customConfirm("정말로 이 참가자를 거부(강퇴)하시겠습니까?")) {
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}/reject/${userId}`, { method: 'POST' });
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || '참가자 거부에 실패했습니다.');
        }

        customAlert(data.message);
        
        const updatedPost = data.post;
        
        if (selectedPost && selectedPost.id == postId) {
            selectedPost = updatedPost;
            renderPostDetailModal();
        }

        const index = allPosts.findIndex(p => p.id == postId);
        if (index !== -1) {
            allPosts[index].currentMembers = updatedPost.currentMembers;
            allPosts[index].isCompleted = updatedPost.isCompleted;
        }
        
        renderPostList();

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}


async function handleInquiry(postId) {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }
    
    if (selectedPost && selectedPost.user_id === currentUser.user_id) {
        customAlert("자신의 게시글에는 문의할 수 없습니다.");
        return;
    }

    try {
        const response = await fetch(`/api/chatrooms/${postId}/create`, { method: 'POST' });
        const data = await response.json();

        if (response.status === 401) {
            customAlert("로그인이 필요합니다.");
            openLoginModal();
            return;
        }
        if (!response.ok) {
            throw new Error(data.error || '채팅방 생성에 실패했습니다.');
        }

        await fetchChatrooms();
        closeDetailModal();
        handleOpenChatDetail(data.id); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleInquiryByAuthor(postId, userId) {
    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        return;
    }

    try {
        const response = await fetch(`/api/chatrooms/create_direct`, { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ post_id: postId, recipient_id: userId })
        });
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || '채팅방 생성에 실패했습니다.');
        }

        await fetchChatrooms();
        closeDetailModal(); 
        handleOpenChatDetail(data.id); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}


async function handleDeletePost(postId) {
    if (!currentUser || currentUser.user_id !== selectedPost.user_id) {
        customAlert("삭제할 권한이 없습니다.");
        return;
    }

    if (!customConfirm("정말로 이 게시글을 삭제하시겠습니까?")) {
        return;
    }

    try {
        const response = await fetch(`/api/posts/${postId}`, { method: 'DELETE' });
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || '삭제에 실패했습니다.');
        }
        
        customAlert('게시글이 삭제되었습니다.');
        closeDetailModal();
        fetchPosts(); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}


async function handleCreatePost(event) {
    event.preventDefault();

    if (!currentUser) {
        customAlert("로그인이 필요한 기능입니다.");
        openLoginModal();
        return;
    }
    
    const formData = new FormData($newPostForm);
    const data = Object.fromEntries(formData.entries());
    
    const current = parseInt(data.currentMembers);
    const total = parseInt(data.totalMembers);

    if (isNaN(current) || isNaN(total)) {
        customAlert("인원수는 숫자만 입력해주세요.");
        return;
    }
    if (current < 1) {
        customAlert("현재 인원은 1명(본인) 이상이어야 합니다.");
        return;
    }
    if (total <= current) {
        customAlert("목표 인원은 현재 인원보다 많아야 합니다.");
        return;
    }
    if (!data.gallery) {
        customAlert("카테고리를 선택해주세요."); 
        return;
    }

    try {
        const response = await fetch('/api/posts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        if (response.status === 401) {
            customAlert("로그인이 필요합니다.");
            openLoginModal();
            return;
        }
        if (response.status === 403) {
            const errorData = await response.json();
            customAlert(errorData.error || '이메일 인증이 필요합니다.');
            return;
        }
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.description || errorData.error || '게시글 등록에 실패했습니다.');
        }

        closeNewPostModal();
        customAlert('게시글이 등록되었습니다!');
        await fetchPosts(); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleLogin(event) {
    event.preventDefault();
    const formData = new FormData($loginForm);
    const data = Object.fromEntries(formData.entries());

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.error || '로그인 실패');
        }
        
        customAlert('로그인 성공!');
        closeLoginModal();
        await fetchAllData(); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function handleRegister(event) {
    event.preventDefault();
    
    const $submitBtn = $registerForm.querySelector('button[type="submit"]');
    const formData = new FormData($registerForm);
    const data = Object.fromEntries(formData.entries());

    try {
        $submitBtn.disabled = true;
        $submitBtn.textContent = '이메일 전송 중...';

        const response = await fetch('/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
        });

        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.error || '회원가입 실패');
        }
        
        customAlert(result.message || '회원가입 성공! 이메일을 확인해주세요.');
        closeRegisterModal();
        openLoginModal(); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    } finally {
        $submitBtn.disabled = false;
        $submitBtn.textContent = '회원가입';
    }
}


async function handleLogout() {
    try {
        const response = await fetch('/logout', { method: 'POST' });
        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || '로그아웃 실패');
        }
        
        customAlert('로그아웃 되었습니다.');
        
        if (chatListRefreshInterval) clearInterval(chatListRefreshInterval);
        if (postDetailRefreshInterval) clearInterval(postDetailRefreshInterval);
        if (chatRefreshInterval) clearInterval(chatRefreshInterval);
        if (postListRefreshInterval) clearInterval(postListRefreshInterval); 
        
        chatListRefreshInterval = null;
        postDetailRefreshInterval = null;
        chatRefreshInterval = null;
        postListRefreshInterval = null; 
        
        currentUser = null;
        renderAuthButtons(); 
        renderPostList(); 
        updateChatBadge(0); 

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

function handleSearch(event) {
    searchTerm = event.target.value;
    renderPostList();
}

function handleGallerySelect(event) {
    const button = event.target.closest('button[data-gallery-id]');
    if (!button) return;
    
    const galleryId = button.dataset.galleryId;
    selectedGallery = galleryId === 'null' ? null : galleryId;
    
    renderSidebar();
    renderPostList();
}

// --- 채팅 이벤트 핸들러 ---

async function handleOpenChatDetail(chatroomId) {
    try {
        const response = await fetch(`/api/chatrooms/${chatroomId}/messages`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || '채팅방 입장에 실패했습니다.');
        }
        
        selectedChatroom = data.chatroom;
        $chatOtherUserName.textContent = selectedChatroom.other_user_name;
        $chatPostTitle.textContent = selectedChatroom.post_title;
        
        renderChatMessages(data.messages);
        
        // [추가] 입력창 상태 갱신
        updateChatInputState();
        
        closeChatListModal();
        openChatDetailModal();
        
        await fetchChatrooms();
        
        if (chatRefreshInterval) clearInterval(chatRefreshInterval);
        chatRefreshInterval = setInterval(refreshChatMessages, 1000);

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

// [수정] 상대방 나갔는지 확인
async function handleSendMessage(event) {
    event.preventDefault();
    if (!selectedChatroom) return;

    // [추가] 상대방이 나갔는지 프론트에서 먼저 확인
    const amIUser1 = currentUser.user_id === selectedChatroom.user1_id;
    const otherUserHasLeft = amIUser1 ? selectedChatroom.user2_left : selectedChatroom.user1_left;
    
    if (otherUserHasLeft) {
        customAlert("상대방이 채팅방을 나갔습니다. 메시지를 보낼 수 없습니다.");
        return;
    }

    const content = $chatMessageInput.value.trim();
    if (!content) return;

    try {
        const response = await fetch(`/api/chatrooms/${selectedChatroom.id}/messages`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: content }),
        });
        
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || '메시지 전송 실패');
        }
        
        $chatMessageInput.value = '';
        await refreshChatMessages();
        
        await fetchChatrooms();

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}

async function refreshChatMessages() {
    if (!selectedChatroom || !currentUser) {
        if (chatRefreshInterval) clearInterval(chatRefreshInterval);
        return;
    }
    
    try {
        const response = await fetch(`/api/chatrooms/${selectedChatroom.id}/messages`);
        if (!response.ok) {
             // 403 (내가 나감) 등
            if (chatRefreshInterval) clearInterval(chatRefreshInterval);
            closeChatDetailModal();
            throw new Error('Chat refresh failed, room likely left');
        }
        
        const data = await response.json();
        
        if ($chatDetailModal.classList.contains('hidden')) {
             if (chatRefreshInterval) clearInterval(chatRefreshInterval);
             return;
        }
        
        // [추가] 갱신된 채팅방 정보로 selectedChatroom 업데이트
        selectedChatroom = data.chatroom;
        
        renderChatMessages(data.messages);
        
        // [추가] 갱신된 정보로 입력창 상태 업데이트
        updateChatInputState(); 
        
    } catch (error) {
        console.error(error);
    }
}

async function handleDeleteChatroom(chatroomId) {
    if (!customConfirm("정말로 이 채팅방을 나가시겠습니까?\n상대방에게는 내가 나갔다는 알림이 표시됩니다.")) {
        return;
    }
    
    try {
        const response = await fetch(`/api/chatrooms/${chatroomId}`, { method: 'DELETE' });
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || '채팅방 나가기 실패');
        }
        
        customAlert(data.message);
        
        await fetchChatrooms();

    } catch (error) {
        console.error(error);
        customAlert(error.message);
    }
}


// --- 앱 초기화 ---

function initApp() {
    // 아이콘 생성
    createIconsSafe();

    // --- 이벤트 리스너 바인딩 ---
    $logo.addEventListener('click', () => window.location.reload());
    $searchInput.addEventListener('input', handleSearch);
    $galleryNav.addEventListener('click', handleGallerySelect);

    // 모달 열기 버튼
    $openNewPostModalBtn.addEventListener('click', openNewPostModal);
    $openChatListBtn.addEventListener('click', openChatListModal);

    // 모달 닫기 버튼
    $closeDetailModalBtn.addEventListener('click', closeDetailModal);
    $closeNewPostModalBtn.addEventListener('click', closeNewPostModal);
    $closeLoginModalBtn.addEventListener('click', closeLoginModal);
    $closeRegisterModalBtn.addEventListener('click', closeRegisterModal);
    $closeChatListModalBtn.addEventListener('click', closeChatListModal);
    $closeChatDetailModalBtn.addEventListener('click', closeChatDetailModal);
    $customAlertCloseBtn.addEventListener('click', closeCustomAlert);

    // 폼 제출
    $newPostForm.addEventListener('submit', handleCreatePost);
    $loginForm.addEventListener('submit', handleLogin);
    $registerForm.addEventListener('submit', handleRegister);
    $chatMessageForm.addEventListener('submit', handleSendMessage);
    
    // 모달 스위칭
    $toggleToRegister.addEventListener('click', openRegisterModal);
    $toggleToLogin.addEventListener('click', openLoginModal);

    // 초기 데이터 로드
    fetchAllData();
}

// DOM이 로드되면 앱 실행
document.addEventListener('DOMContentLoaded', initApp);